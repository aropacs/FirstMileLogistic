// =========================================================
// FirstMile Logistic — Main Script
// 1. Mobile menu open / close
// 2. Show a "thank you" message when a form is submitted
//    (static website, so the form data is not sent anywhere)
// =========================================================


// 1. Mobile menu
const menuBtn = document.querySelector(".menu-btn");
const navbar = document.querySelector(".navbar");

if (menuBtn && navbar) {
  menuBtn.addEventListener("click", function () {
    navbar.classList.toggle("open");

    const icon = menuBtn.querySelector("i");
    const isOpen = navbar.classList.contains("open");

    // change icon: bars <-> close
    icon.className = isOpen ? "fa-solid fa-xmark" : "fa-solid fa-bars";
    menuBtn.setAttribute("aria-expanded", isOpen);
  });
}


// 2. Forms with class "static-form"
const forms = document.querySelectorAll(".static-form");

forms.forEach(function (form) {
  form.addEventListener("submit", function (event) {
    event.preventDefault(); // stop page reload

    const message = form.querySelector(".form-success");
    if (message) {
      message.classList.add("show");
    }

    form.reset();
  });
});
